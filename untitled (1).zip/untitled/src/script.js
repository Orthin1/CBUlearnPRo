let currentFolder = "";

const notesData = {

    "Mathematics 110": [],

    "Chemistry 110": [],

    "Physics 110": [],

    "Biology 110": []

};

function enterFolder(folderName) {

    currentFolder = folderName;

    document.getElementById("folderTitle").innerText = folderName;

    document.getElementById("mainMenu").style.display = "none";

    document.getElementById("folderView").style.display = "block";

    displayNotes();

}

function goBack() {

    document.getElementById("mainMenu").style.display = "block";

    document.getElementById("folderView").style.display = "none";

}

function addNote() {

    const noteInput = document.getElementById("noteInput");

    const noteText = noteInput.value;

    if (noteText) {

        notesData[currentFolder].push(noteText);

        noteInput.value = "";

        displayNotes();

    } else {

        alert("Please enter a note!");

    }

}

function deleteNote(index) {

    notesData[currentFolder].splice(index, 1);

    displayNotes();

}

function displayNotes() {

    const notesDiv = document.getElementById("notes");

    notesDiv.innerHTML = "";

    notesData[currentFolder].forEach((note, index) => {

        const noteDiv = document.createElement("div");

        noteDiv.className = "note";

        noteDiv.innerHTML = `

            <p>${note}</p>

            <button class="deleteBtn" onclick="deleteNote(${index})">Delete</button>

        `;

        notesDiv.appendChild(noteDiv);

    });

}